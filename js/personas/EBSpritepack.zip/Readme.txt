CREDITS

Credit to the people who ripped those sprites from the 3ds game
Ploaj 

The developers who made This Extreme Butouden Game
A lot of sprites were altered and stuff

https://www.spriters-resource.com/3ds/dragonballzextremebutoden/sheet/67247/